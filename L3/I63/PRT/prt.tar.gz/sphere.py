from objet import Objet
from couleur import Couleur
from point import Point
from vecteur import Vecteur
from ray import Ray


class Sphere(Objet):

    def __init__(self, pos : Point, coul=Couleur(Point(255, 0, 0)), ambiant=Vecteur(Point(0.1, 0, 0)), diffu=Vecteur(Point(0.7, 0, 0)), spec=Vecteur(Point(1, 1, 1)), reflex = 100, ombr=False, r=0.5):
        super().__init__(pos, coul, ambiant, diffu, spec, reflex, ombr)
        self.rayon = r

    def __str__(self):
        return f'{super().__str__()} \n rayon = {self.rayon}'

    def __repr__(self) -> str:
        return str(self)


    def intersection(self, rayon_vue : Ray):
        cp = Vecteur(rayon_vue.origine, self.position)
        b = 2 * rayon_vue.direction.prod_scal(cp)
        c = cp.prod_scal(cp) - self.rayon ** 2
        #c = ((Vecteur(rayon_vue.origine, self.position)).norme()) ** 2 - self.rayon ** 2
        #a = 1
        
        delta = b * b - 4 * c
        #print(cp, b, c, delta)
        if delta > 0:
            #print(b, delta)
            t1 = (-b + (delta ** 0.5)) / 2
            t2 = (-b - (delta ** 0.5)) / 2
            #print(t1,t2)
            if t1 > 0 and t2 > 0 :
                
                return min(t1, t2)
            else:
                return float('inf')

        
        elif delta == 0:
            return -b/2
        else:
            return float('inf')
     
    



if __name__ == "__main__":

    sphere1 = (Sphere(Point(1,1,1), r=0.2))
    print(sphere1.couleur)


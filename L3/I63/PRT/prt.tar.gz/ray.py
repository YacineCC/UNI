from point import Point
from vecteur import Vecteur
class Ray:

    def __init__(self, origine: Point, direction: Vecteur):
        """
        un rayon de vue est une demie droite définie par une origine et un vecteur directeur
        on dira que l'origine est le foyer de l'image et non pas le centre du pixel
        """
        
        self.origine = origine
        self.direction = direction.normalisation()


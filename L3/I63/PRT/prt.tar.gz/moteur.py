from ray import Ray
from point import Point
from couleur import Couleur
from vecteur import Vecteur
from scene import Scene
from camera import Camera
from sphere import Sphere
from lumiere import Lumiere
from PIL import Image
import numpy as np
from plan import Plan

class Moteur:


    def nearest_intersected_object(self, scene, origine, direction):

        distances = []
        for obj in scene.objets:
            distances.append(self.intersection(origine, direction))
        nearest_objet = None
        min_distance = float('inf')
        for index, distance in enumerate(distances):
            if distance < min_distance:
                nearest_objet = scene.objets[index]
        
        return nearest_objet, min_distance



    def ray_casting(self, scene : Scene):
        MAX_DIST = float('inf')
        L = []
        nb_inter = 0
        for y in range(scene.camera.hauteur) :
            for x in range(scene.camera.largeur):
                i = MAX_DIST
                #pixel = scene.camera.pixel(x,y) # point du centre du pixel pour le rayon_vue
                #origine = scene.camera.focale # foyer
                rayon_vue = scene.camera.rayon_vue(x, y)


                for objet in scene.objets:
                    dist = objet.intersection(rayon_vue)
                    
                    if dist < MAX_DIST :
                        #print(dist)
                        i = dist
                        
                        
                if i != MAX_DIST:
                    L.append(objet.couleur.tup)
                    nb_inter += 1
                    #L.append((255,0,0))
                    #print(i)
                    #print(x,y)
                    # norm = (pixel + i).normalisation()
                    # for lumiere in scene.lumieres:
                    #     #rayon(i, lumiere)
                    #     for objet in scene.objets:
                    #         if objet != i:
                    #             dist = objet.intersection(norm, lumiere)
                    #             if dist < 0:
                    #                 coul = scene.fond
                else :
                    #L.append(Couleur(Vecteur(Point(0,0,0))))
                    L.append((100,100,100))
                #image.set_pixel(x,y, coul)
        print(nb_inter)
        return L


if __name__ == "__main__":

    M = Moteur()
    WIDTH = 320
    HEIGHT = 200
    
    camera = Camera(Point(0, 0, 0), [WIDTH, HEIGHT], Vecteur(Point(0, 0, 1)), Vecteur(Point(0, 1, 0)), 5)

    #objets = [Sphere(Point(0, 0, 0), r=0.1), Sphere(Point(10, 10, -10), r=0.5), Sphere(Point(-10, -10, -2), r=0.5)]
    #objets = [Sphere(pos=Point(0, 0, -10), r=13)]
    objets = [Plan(pos=Point(0, -10, 0), dir=Vecteur(Point(0, 1, 0))),Plan(pos=Point(0, 0, -10), coul=Couleur(Point(0, 255, 0)),  dir=Vecteur(Point(0, 0, 1)))]

    lumieres = [Lumiere(Point(5, 10, -3), Couleur(Point(255, 255, 255)))]

    scene = Scene(camera, objets, lumieres, WIDTH, HEIGHT)
    L = (M.ray_casting(scene))
    #L = np.array(L)
    #print(len(L))
    im = Image.new('RGB', (WIDTH, HEIGHT))
    im.putdata(L)
    im.show()
    #PIL_image = Image.fromarray(np.array(L))

    #PIL_image = Image.fromarray(L.astype('uint8'), 'RGB')
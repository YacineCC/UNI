from narray import Narray
import numpy as np
class Point(Narray):
    pass


if __name__ == "__main__":
    A = Point(1,2,3)
    B = Point(1,2,3)
    print(A.x)

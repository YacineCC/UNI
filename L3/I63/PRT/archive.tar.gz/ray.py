class Ray:

    def __init__(self, origine, direction):
        
        self.origine = origine
        self.direction = direction.normalize()

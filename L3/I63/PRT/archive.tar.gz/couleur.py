from vecteur import Vecteur
from point import Point


class Couleur(Vecteur):
    """ Triplets np.array RVB"""
    pass



if __name__ == "__main__":

    print(Couleur(Point(0,0,255)))
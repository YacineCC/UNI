from narray import Narray
from point import Point
import numpy as np


class Vecteur(Narray):


    def __init__(self, arrivee : Point, depart=Point(0,0,0)):


        vec =  arrivee.arr - depart.arr 
        super().__init__(vec[0], vec[1], vec[2])
        #self.__composantes = p2.arr - p1.arr


    def __mul__(self, scal : int | float): # Méthode spéciale surcharge de l'opérateur *


        """ Produit vecteur scalaire. Retourne un Vecteur."""
        vec = self.arr * scal
        return Vecteur(Point(vec[0], vec[1], vec[2]))
    
    
    
    def prod_vec(self, v2):


        """ Produit vectoriel. Retourne un Vecteur."""
        vec = np.cross(self.arr, v2.arr)
        return Vecteur(Point(vec[0], vec[1], vec[2]))
    
    def prod_scal(self, v2) -> int: 


        """ Produit scalaire de deux vecteurs."""
        return np.dot(self.arr, v2.arr)
    

    def __add__(self, v2): # Méthode spéciale surcharge de l'opérateur +


        """ Addition de deux Vecteurs. Retourne un Vecteur."""
        vec = self.arr + v2.arr
        return Vecteur(Point(vec[0], vec[1], vec[2]))
    
    
    def __sub__(self, v2): # Méthode spéciale surcharge de l'opérateur -


        """ Soustraction de deux Vecteurs. Retourne un Vecteur."""
        vec = self.arr - v2.arr
        return Vecteur(Point(vec[0], vec[1], vec[2]))
    

    def norme(self) -> float:
            

        return np.dot(self.arr, self.arr) ** 0.5


    def normalisation(self):


        norme = self.norme()
        vec = self.arr / norme
        return Vecteur(Point(vec[0], vec[1], vec[2]))


if __name__ == "__main__":


    A = Vecteur(Point(5,14, 19), Point(0,0,0))
    B = Vecteur(Point(1,2,3))
    C = (A - B).normalisation()
    print(C, C.norme())

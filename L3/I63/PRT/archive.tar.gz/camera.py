from point import Point


class Camera(Point):
    pass

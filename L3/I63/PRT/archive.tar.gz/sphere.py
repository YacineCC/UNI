from objet import Objet
from couleur import Couleur
from point import Point
from vecteur import Vecteur


class Sphere(Objet):

    def __init__(self, pos : Point, coul=Couleur(Point(255, 0, 0)), ambiant=Vecteur(Point(0.1, 0, 0)), diffu=Vecteur(Point(0.7, 0, 0)), spec=Vecteur(Point(1, 1, 1)), reflex = 100, ombr=False, r=0.5):
        super().__init__(pos, coul, ambiant, diffu, spec, reflex, ombr)
        self.rayon = r

    def __str__(self):
        return f'{super().__str__()} \n rayon = {self.rayon}'

    def __repr__(self) -> str:
        return str(self)


    def intersection(self, origine, direction):
        b = 2 * direction.prod_scal(origine - self.position)
        c = (origine - self.position).normalisation() ** 2 - self.rayon ** 2
        #a = 1
        delta = b ** 2 - 4 * c
        if delta > 0:
            t1 = (-b + delta ** 0.5) / 2
            t2 = (-b + delta ** 0.5) / 2
            if t1 > 0 and t2 > 0 :
                return min(t1, t2)
        return None
     
    



if __name__ == "__main__":

    sphere1 = (Sphere(Point(1,1,1), r=0.2))
    print(sphere1)


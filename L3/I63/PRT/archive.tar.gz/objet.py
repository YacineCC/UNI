from couleur import Couleur
from point import Point
from vecteur import Vecteur
class Objet:

    def __init__(self, pos : Point, coul=Couleur(Point(255, 0, 0)), ambiant=Vecteur(Point(0.1, 0, 0)), diffu=Vecteur(Point(0.7, 0, 0)), spec=Vecteur(Point(1, 1, 1)), reflex = 100, ombr=False):
        self.position = pos # centre de la sphere
        self.couleur = coul
        self.ambiant = ambiant
        self.diffus = diffu
        self.speculaire = spec
        self.reflexion = reflex
        self.ombre = ombr
    


    def __str__(self) -> str:
        return f'position : {self.position}\n couleur {self.couleur}\n ambiant : {self.ambiant}\n diffus : {self.diffus}\n speculaire : {self.speculaire}\n reflexion : {self.reflexion}\n ombre : {self.ombre}'
    
    def __repr__(self) -> str:
        return str(self)

    def intersection(self, ray):
        """ Regarde si intersection entre le ray et l'objet, retourne la distance
          de l'intersection ou None si pas d'intersection"""
        
        sphere_to_ray = ray.origin - self.centre
        #a = 1
        b = 2 * ray.direction.prod_scal(sphere_to_ray)
        c = sphere_to_ray.prod_scal(sphere_to_ray) - self.rayon * self.rayon
        discriminant = b*b - 4 * c

        if discriminant >= 0:
            dist = (-b - discriminant ** 0.5) / 2

            if dist > 0:
                return dist
        return None

    def normale():
        pass


if __name__ == "__main__":

    print(Objet(Point(1,1,1)))
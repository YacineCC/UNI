from PIL import Image

# class Image:


#     def init_image(width, height):

#         for
from objet import Objet
from vecteur import Vecteur
from couleur import Couleur
from point import Point
from ray import Ray

class Plan(Objet):
    def __init__(self, pos : Point, coul=Couleur(Point(255, 0, 0)), ambiant=Vecteur(Point(0.1, 0, 0)), diffu=Vecteur(Point(0.7, 0, 0)), spec=Vecteur(Point(1, 1, 1)), reflex = 100, ombr=False, dir=Vecteur(Point(0, 1, 0))):
        super().__init__(pos, coul, ambiant, diffu, spec, reflex, ombr)
        self.direction = dir.normalisation()

    def __str__(self):
        return f'{super().__str__()} \n direction = {self.direction}'

    def __repr__(self) -> str:
        return str(self)
    
    def normale(self, pt):
        return self.direction
    

    def intersection(self, ray : Ray):
        denom = self.direction.prod_scal(ray.direction)
        if abs(denom) > 0.0000001:
            t = (Vecteur(self.position, ray.origine)).prod_scal(self.direction) / denom

        return t
if __name__ == "__main__":

    print(Plan((0, 0, 0)))
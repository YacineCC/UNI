from PIL import Image
from couleur import Couleur
from camera import Camera
from point import Point
from sphere import Sphere
from moteur import Render

from scene import Scene


def main():
    WIDTH = 320
    HEIGHT = 200
    
    camera = Camera(Point(0, 0, 1))

    objets = [Sphere(Point(0, 0, 10), 0.5)]

    lumieres = [lumieres(Point(5, 10, -3), Couleur(255, 255, 255))]

    scene = Scene(camera, objets, lumieres, WIDTH, HEIGHT)

    #engine = 

    list_of_pixels = Render(scene)
    img = Image.new("RGBA", (WIDTH, HEIGHT))
    img.putdata(list_of_pixels)

    img.show()


from point import Point
from vecteur import Vecteur
class Ray:

    def __init__(self, origine: Point, direction: Vecteur):
        """
        un rayon de vue est une demie droite définie par une origine et un vecteur directeur
        on dira que l'origine est le foyer de l'image et non pas le centre du pixel
        """
        
        self.origine = origine
        self.direction = direction.normalisation()
        #self.direction = direction

    def get_point(self, t : float):
        x = self.origine.x + t * self.direction.x
        y = self.origine.y + t * self.direction.y
        z = self.origine.z + t * self.direction.z
        return Point(x, y, z) 
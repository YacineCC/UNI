from ray import Ray
from point import Point
from couleur import Couleur
from vecteur import Vecteur
from scene import Scene
from camera import Camera
from sphere import Sphere
from lumiere import Lumiere
from PIL import Image
import numpy as np
from plan import Plan

class Moteur:



    def ray_casting(self, scene : Scene):
        MAX_DIST = 1e3
        L = []
        nb_inter = 0
        # r_vue = scene.camera.rayon_vue(319, 199)
        # print("rayon direction : ",r_vue.direction)
        # dist = scene.objets[0].intersection(r_vue)
        # print(dist)
        # return
        compteur = 0
        for y in range(scene.camera.hauteur*10) :
            
            for x in range(scene.camera.largeur*10):
                # if y == 0:
                #     print("x", x)
                min_dist = MAX_DIST
                closest_obj = None
                #pixel = scene.camera.pixel(x,y) # point du centre du pixel pour le rayon_vue
                #origine = scene.camera.focale # foyer
                rayon_vue = scene.camera.rayon_vue(x, y)
                if compteur < 20:
                    compteur += 1
                    print(compteur,"Rayon",rayon_vue.direction)
                for objet in scene.objets:
                    dist = objet.intersection(rayon_vue)
                    
                    if dist < min_dist :
                        #print(dist)
                        min_dist = dist
                        closest_obj = objet
                        
                # Si pas d'intersection trouvée, couleur noire
                if closest_obj is None:
                    L.append((100, 100, 100))
                else:
                    # Sinon on met la couleur de l'objet
                    pt = rayon_vue.get_point(min_dist)
                    normale = closest_obj.normale(pt)
                    direction_lum = Vecteur(scene.lumieres[0].position, pt).normalisation()
                    color = normale.prod_scal(direction_lum) * closest_obj.couleur
                    L.append((int(color.x), int(color.y), int(color.z)))
                    
                    #     L.append(closest_obj.couleur.tup)
                    #     #print(min_dist)
                    #     nb_inter += 1
                    #     #L.append((255,0,0))
                    #     #print(i)
                    #     #print(x,y)
                    #     # norm = (pixel + i).normalisation()
                    #     # for lumiere in scene.lumieres:
                    #     #     #rayon(i, lumiere)
                    #     #     for objet in scene.objets:
                    #     #         if objet != i:
                    #     #             dist = objet.intersection(norm, lumiere)
                    #     #             if dist < 0:
                    #     #                 coul = scene.fond
                    # else :
                    #     #L.append(Couleur(Vecteur(Point(0,0,0))))
                    #     L.append((100,100,100))
                    # #image.set_pixel(x,y, coul)
            
        print("nb inter", nb_inter)
        return L


if __name__ == "__main__":

    M = Moteur()
    WIDTH = 32
    HEIGHT = 20
    

    camera = Camera(Point(0, 0, 0), [HEIGHT, WIDTH], Vecteur(Point(0, 0, 1)), Vecteur(Point(0, 1, 0)), 5)


    #objets = [Sphere(Point(0, 0, 0), r=0.1), Sphere(Point(10, 10, -10), r=0.5), Sphere(Point(-10, -10, -2), r=0.5)]
    PLAN_MUR_DROIT = Plan(pos=Point(10, 0, 0), dir=Vecteur(Point(-1, 0, 0) ))
    PLAN_MUR_FACE = Plan(pos=Point(0, 0, -10), coul= Couleur(Point(0, 255, 0)), dir=Vecteur(Point(0, 0, 1)))
    objets = [Sphere(pos=Point(0, 0, -3), r=3), Sphere(pos=Point(1, 0, -3), coul=Couleur(Point(255, 0, 255)),r=3), PLAN_MUR_FACE]


    lumieres = [Lumiere(Point(-2, 3, 2), Couleur(Point(255, 255, 255)))]

    scene = Scene(camera, objets, lumieres, WIDTH, HEIGHT)
    L = (M.ray_casting(scene))


    im = Image.new('RGB', (WIDTH*10, HEIGHT*10))
    im.putdata(L)
    im.save("test.png")



    #PIL_image = Image.fromarray(np.array(L))

    #PIL_image = Image.fromarray(L.astype('uint8'), 'RGB')